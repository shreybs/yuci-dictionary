# nontype dictionary

A tiny CLI dictionary built by python, based on youdao-web dictionary and require an internet connection. 

